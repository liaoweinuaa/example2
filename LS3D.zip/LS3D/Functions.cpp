#include "Constants.h"
#include <math.h>
#include <thread>
#include <string>
#include <fstream>
#include <iostream>
using namespace std;



//The following two-dimensional array is used in the rough computation phase to save the values of the value function at the grid points
extern double(*Arr_StateValueR)[Nry][Nrphi];
extern double(*Arr_StateValueNewR)[Nry][Nrphi];
extern State(*Arr_StateR)[Nry][Nrphi];// Used to save the state of each grid point representation (For rough computation)
//The following two-dimensional array is used in the fine tuning phase to save the values of the value function at the grid points
extern double(*Arr_StateValueF)[Nfy][Nfphi];
extern double(*Arr_StateValueNewF)[Nfy][Nfphi];
extern State(*Arr_StateF)[Nfy][Nfphi];// Used to save the state of each grid point representation (For fine tuning)


bool Func_IsInTargetSet(State s)
{
	if (abs(s.y) <= 0.5 && s.x <= 2.5 && s.x >= 1.5)
	{
		return true;
	}
	else
	{
		return false;
	}
}


void Func_Initial()
{
	memset(Arr_StateValueR, 0, sizeof(double) * Nrx * Nry * Nrphi);
	memset(Arr_StateValueF, 0, sizeof(double) * Nfx * Nfy * Nfphi);

	for (int i = 0; i < Nrx; i++)
	{
		for (int j = 0; j < Nry; j++)
		{
			for (int k = 0; k < Nrphi; k++)
			{
				double x = xmin + gridrx * i;
				double y = ymin + gridry * j;
				double phi = phimin + gridrphi * k;

				Arr_StateR[i][j][k].x = x;
				Arr_StateR[i][j][k].y = y;
				Arr_StateR[i][j][k].phi = phi;
			}
		}
	}

	for (int i = 0; i < Nfx; i++)
	{
		for (int j = 0; j < Nfy; j++)
		{
			for (int k = 0; k < Nfphi; k++)
			{
				double x = xmin + gridfx * i;
				double y = ymin + gridfy * j;
				double phi = phimin + gridfphi * k;

				Arr_StateF[i][j][k].x = x;
				Arr_StateF[i][j][k].y = y;
				Arr_StateF[i][j][k].phi = phi;
			}
		}
	}
}



State Func_Transition(State s, double a)
{
	if (Func_IsInTargetSet(s))
	{
		return s;
	}

	double x = s.x, y = s.y, phi = s.phi;
	double dotx = 5 * cos(phi) - x + 0.3 * y * y * y;
	double doty = 5 * sin(phi) - x + 0.1 * x * x * x;
	double dotphi = a;

	double x1 = x + dotx * dt;// + 0.5 * ddotv * dt * dt;
	double y1 = y + doty * dt;// +0.5 * ddotgamma * dt * dt;
	double phi1 = phi + dotphi * dt;// +0.5 * ddoth * dt * dt;

	if (x1 < xmin)
	{
		x1 = xmin + 0.0001;
	}
	if (y1 < ymin)
	{
		y1 = ymin + 0.0001;
	}
	if (phi1 < phimin)
	{
		phi1 = phi1 + 2 * PI;
	}

	if (x1 > xmax)
	{
		x1 = xmax - 0.0001;
	}
	if (y1 > ymax)
	{
		y1 = ymax - 0.0001;
	}
	if (phi1 > phimax)
	{
		phi1 = phi1 - 2 * PI;
	}



	return State{ x1,y1,phi1 };

}

double Func_RunningCost(State s0, double u)
{
	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}

	return 1;
}

double Func_InterPolationR(State s0)
{
	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}
	double ix_double = ((s0.x - xmin) / gridrx);
	double iy_double = ((s0.y - ymin) / gridry);
	double iphi_double = ((s0.phi - phimin) / gridrphi);

	if (ix_double >= Nrx - 1)
	{
		ix_double = Nrx - 1 - 0.000001;
	}

	if (iy_double >= Nry - 1)
	{
		iy_double = Nry - 1 - 0.000001;
	}

	if (iphi_double >= Nrphi - 1)
	{
		iphi_double = Nrphi - 1 - 0.000001;
	}

	int ix = int(ix_double);
	int iy = int(iy_double);
	int iphi = int(iphi_double);

	double v000 = Arr_StateValueR[ix][iy][iphi];
	double v001 = Arr_StateValueR[ix][iy][iphi + 1];
	double v010 = Arr_StateValueR[ix][iy + 1][iphi];
	double v011 = Arr_StateValueR[ix][iy + 1][iphi + 1];
	double v100 = Arr_StateValueR[ix + 1][iy][iphi];
	double v101 = Arr_StateValueR[ix + 1][iy][iphi + 1];
	double v110 = Arr_StateValueR[ix + 1][iy + 1][iphi];
	double v111 = Arr_StateValueR[ix + 1][iy + 1][iphi + 1];

	double dx0 = ix_double - ix;
	double dx1 = 1 - dx0;
	double dy0 = iy_double - iy;
	double dy1 = 1 - dy0;
	double dphi0 = iphi_double - iphi;
	double dphi1 = 1 - dphi0;

	double V000 = dx0 * dy0 * dphi0;
	double V001 = dx0 * dy0 * dphi1;
	double V010 = dx0 * dy1 * dphi0;
	double V011 = dx0 * dy1 * dphi1;
	double V100 = dx1 * dy0 * dphi0;
	double V101 = dx1 * dy0 * dphi1;
	double V110 = dx1 * dy1 * dphi0;
	double V111 = dx1 * dy1 * dphi1;

	return (v000 * V111 + v001 * V110 + v010 * V101 + v011 * V100 + v100 * V011 + v101 * V010 + v110 * V001 + v111 * V000);
}

double Func_InterPolationF(State s0)
{
	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}
	double ix_double = ((s0.x - xmin) / gridfx);
	double iy_double = ((s0.y - ymin) / gridfy);
	double iphi_double = ((s0.phi - phimin) / gridfphi);

	/*if (ix_double>=Nrx-1)
	{
		ix_double = Nrx - 1 - 0.000001;
	}

	if (iy_double >= Nry - 1)
	{
		iy_double = Nry - 1 - 0.000001;
	}

	if (iphi_double >= Nrphi - 1)
	{
		iphi_double = Nrphi - 1 - 0.000001;
	}*/

	int ix = int(ix_double);
	int iy = int(iy_double);
	int iphi = int(iphi_double);





	double v000 = Arr_StateValueF[ix][iy][iphi];
	double v001 = Arr_StateValueF[ix][iy][iphi + 1];
	double v010 = Arr_StateValueF[ix][iy + 1][iphi];
	double v011 = Arr_StateValueF[ix][iy + 1][iphi + 1];
	double v100 = Arr_StateValueF[ix + 1][iy][iphi];
	double v101 = Arr_StateValueF[ix + 1][iy][iphi + 1];
	double v110 = Arr_StateValueF[ix + 1][iy + 1][iphi];
	double v111 = Arr_StateValueF[ix + 1][iy + 1][iphi + 1];

	double dx0 = ix_double - ix;
	double dx1 = 1 - dx0;
	double dy0 = iy_double - iy;
	double dy1 = 1 - dy0;
	double dphi0 = iphi_double - iphi;
	double dphi1 = 1 - dphi0;

	double V000 = dx0 * dy0 * dphi0;
	double V001 = dx0 * dy0 * dphi1;
	double V010 = dx0 * dy1 * dphi0;
	double V011 = dx0 * dy1 * dphi1;
	double V100 = dx1 * dy0 * dphi0;
	double V101 = dx1 * dy0 * dphi1;
	double V110 = dx1 * dy1 * dphi0;
	double V111 = dx1 * dy1 * dphi1;

	return (v000 * V111 + v001 * V110 + v010 * V101 + v011 * V100 + v100 * V011 + v101 * V010 + v110 * V001 + v111 * V000);
}

double Func_ValueUnderOptInputR(int i, int j, int k)
{
	State s0 = Arr_StateR[i][j][k];
	double minvalue = 10000000;

	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}

	for (int j = 0; j < Na; j++)
	{
		double a = amin + j * da;
		State snew = Func_Transition(s0, a);
		double value = 0.9862327 * Func_InterPolationR(snew) + Func_RunningCost(s0, a) * 0.009931;

		if (value < minvalue)
		{
			minvalue = value;
		}

	}
	return minvalue;
}

double Func_ValueUnderOptInputF(int i, int j, int k)
{
	State s0 = Arr_StateF[i][j][k];
	double minvalue = 10000000;

	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}

	for (int j = 0; j < Na; j++)
	{
		double a = amin + j * da;


		State snew = Func_Transition(s0, a);
		// I wrote the calculations for expressions gamma^dt and (gamma^dt-1)/ln(gamma) directly here
		// You can modify the values here according to dt and gamma.
		double value = 0.9862327 * Func_InterPolationF(snew) + Func_RunningCost(s0, a) * 0.009931;

		if (value < minvalue)
		{
			minvalue = value;
		}

	}
	return minvalue;
}





void Func_RecursionSTR(int threadid)
{
	//Compute recursion using a single thread
	// for threadid=0, the values of I are 0, thread_num, 2*thread_num, .....
	// for threadid=1, the values of I are 1, thread_num+1, 2*thread_num+1, .....
	for (int I = threadid; I < Nrx; I += thread_num)
	{
		for (int j = 0; j < Nry; j++)
		{
			for (int k = 0; k < Nrphi; k++)
			{
				Arr_StateValueNewR[I][j][k] = Func_ValueUnderOptInputR(I, j, k);
			}
		}


	}
}


void Func_RecursionSTF(int threadid)
{
	//Compute recursion using a single thread
	// for threadid=0, the values of I are 0, thread_num, 2*thread_num, .....
	// for threadid=1, the values of I are 1, thread_num+1, 2*thread_num+1, .....
	for (int I = threadid; I < Nfx; I += thread_num)
	{
		for (int j = 0; j < Nfy; j++)
		{
			for (int k = 0; k < Nfphi; k++)
			{
				Arr_StateValueNewF[I][j][k] = Func_ValueUnderOptInputF(I, j, k);
			}
		}
	}
}

void Func_Upsampling()
{
	for (int i = 0; i < Nfx; i++)
	{
		for (int j = 0; j < Nfy; j++)
		{
			for (int k = 0; k < Nfphi; k++)
			{
				Arr_StateValueF[i][j][k] = Func_InterPolationR(Arr_StateF[i][j][k]);
			}
		}
	}
}



void Func_RecursionMTR()
{
	//Compute recursion using multi-thread, threadid=0,1,2,...,thread_num-1

	thread t0(Func_RecursionSTR, 0);
	thread t1(Func_RecursionSTR, 1);
	thread t2(Func_RecursionSTR, 2);
	thread t3(Func_RecursionSTR, 3);
	thread t4(Func_RecursionSTR, 4);
	thread t5(Func_RecursionSTR, 5);
	thread t6(Func_RecursionSTR, 6);
	thread t7(Func_RecursionSTR, 7);
	thread t8(Func_RecursionSTR, 8);
	thread t9(Func_RecursionSTR, 9);

	t0.join();
	t1.join();
	t2.join();
	t3.join();
	t4.join();
	t5.join();
	t6.join();
	t7.join();
	t8.join();
	t9.join();

	memcpy(Arr_StateValueR, Arr_StateValueNewR, sizeof(double) * Nrx * Nry * Nrphi);
}

void Func_RecursionMTF()
{
	//Compute recursion using multi-thread, threadid=0,1,2,...,thread_num-1

	thread t0(Func_RecursionSTF, 0);
	thread t1(Func_RecursionSTF, 1);
	thread t2(Func_RecursionSTF, 2);
	thread t3(Func_RecursionSTF, 3);
	thread t4(Func_RecursionSTF, 4);
	thread t5(Func_RecursionSTF, 5);
	thread t6(Func_RecursionSTF, 6);
	thread t7(Func_RecursionSTF, 7);
	thread t8(Func_RecursionSTF, 8);
	thread t9(Func_RecursionSTF, 9);

	t0.join();
	t1.join();
	t2.join();
	t3.join();
	t4.join();
	t5.join();
	t6.join();
	t7.join();
	t8.join();
	t9.join();

	memcpy(Arr_StateValueF, Arr_StateValueNewF, sizeof(double) * Nfx * Nfy * Nfphi);
}


void Func_SavaData(string filename0, string filename1)
{
	// Save the results of the rough computation as a column of data
	// When using drawing software, after importing the results, you need to reshape the data into a Nrx * Nry * Nrphi 3D array, 
	// which may also need to be transposed (depending on the rules of the drawing software)
	ofstream ofs0;
	ofs0.open(filename0);
	for (int i = 0; i < Nrx; i += 1)
	{
		for (int j = 0; j < Nry; j += 1)
		{
			for (int k = 0; k < Nrphi; k += 1)
			{
				ofs0 << Arr_StateValueR[i][j][k] << endl;
			}
		}
	}
	ofs0.close();


	// Save the results of the fine tuning as a column of data
	// When using drawing software, after importing the results, you need to reshape the data into a 
	// ((Nfx-1)/save_step+1) * ((Nfy-1)/save_step+1) * ((Nfphi-1)/save_step+1) 3D array, 
	// which may also need to be transposed (depending on the rules of the drawing software)
	ofstream ofs1;
	ofs1.open(filename1);
	for (int i = 0; i < Nfx; i += save_step)
	{
		for (int j = 0; j < Nfy; j += save_step)
		{
			for (int k = 0; k < Nfphi; k += save_step)
			{
				ofs1 << Arr_StateValueF[i][j][k] << endl;
			}
		}
	}
	ofs1.close();
}