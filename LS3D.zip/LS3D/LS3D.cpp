﻿// VariableSize3D.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "Constants.h"
#include "Functions.h"
#include <string>
using namespace std;


//The following two-dimensional array is used in the rough computation phase to save the values of the value function at the grid points
double(*Arr_StateValueR)[Nry][Nrphi] = new double[Nrx][Nry][Nrphi];
double(*Arr_StateValueNewR)[Nry][Nrphi] = new double[Nrx][Nry][Nrphi];
State(*Arr_StateR)[Nry][Nrphi] = new State[Nrx][Nry][Nrphi];// Used to save the state of each grid point representation (For rough computation)
//The following two-dimensional array is used in the fine tuning phase to save the values of the value function at the grid points
double(*Arr_StateValueF)[Nfy][Nfphi] = new double[Nfx][Nfy][Nfphi];
double(*Arr_StateValueNewF)[Nfy][Nfphi] = new double[Nfx][Nfy][Nfphi];
State(*Arr_StateF)[Nfy][Nfphi] = new State[Nfx][Nfy][Nfphi];// Used to save the state of each grid point representation (For fine tuning)


int main()
{
	Func_Initial();
	for (int i = 0; i < 100; i++)
	{
		cout << i << endl;
		Func_RecursionMTR();
	}
	cout << "Func_Upsampling" << endl;
	Func_Upsampling();
	for (int i = 0; i < 10; i++)
	{
		Func_RecursionMTF();
	}
	Func_SavaData("rough.csv", "finetuning.csv");
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
