#pragma once
const double PI = 3.1415927;
const double xmin = -4;
const double xmax = 4;
const double ymin = -4;
const double ymax = 4;
const double phimin = 0;
const double phimax = 2 * PI;

const int Nrx = 51;
const int Nry = 51;
const int Nrphi = 51;


const double gridrx = (xmax - xmin) / (Nrx - 1);
const double gridry = (ymax - ymin) / (Nry - 1);
const double gridrphi = (phimax - phimin) / (Nrphi - 1);



const int Nfx = 201;
const int Nfy = 201;
const int Nfphi = 201;

//const int Ntotal = Nx * Ny * Nphi;

const double gridfx = (xmax - xmin) / (Nfx - 1);
const double gridfy = (ymax - ymin) / (Nfy - 1);
const double gridfphi = (phimax - phimin) / (Nfphi - 1);

const double amin = -1;
const double amax = 1;

const int Na = 11;
const double da = (amax - amin) / (Na - 1);


struct State
{
	double x; double y; double phi;
};


const double dt = 0.01;
const double gamma = 0.25;
const int save_step = 2; // The precision of the saved data, e.g., when the number of grids is 101x101x101, if save_step=2, then 51x51x51 numbers will be saved
const int thread_num = 10;//Depending on the user's cpu reality











