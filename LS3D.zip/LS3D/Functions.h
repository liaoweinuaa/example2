#pragma once
#include <string>
using namespace std;
void Func_Initial();
void Func_Upsampling();
void Func_RecursionMTF();
void Func_RecursionMTR();
void Func_SavaData(string filename0, string filename1);